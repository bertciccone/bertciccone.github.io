# frontend-nanodegree-feedreader

## Feed Reader Tests

Use Jasmine to test Feed Reader specifications.

## Running the app

Browse to [Feed Reader Tests](https://bertcuda.github.io/frontend-nanodegree-feedreader/index.html).

## Downloading sources and running locally

Use Git to clone the app at [frontend-nanodegree-feedreader](https://github.com/bertcuda/frontend-nanodegree-feedreader.git) into your local folder. Alternatively, download the frontend-nanodegree-feedreader.zip file at [frontend-nanodegree-feedreader](https://github.com/bertcuda/frontend-nanodegree-feedreader.git) into your local folder. After cloning or unzipping, navigate into the `frontend-nanodegree-feedreader` folder and open `index.html` in your browser to run the app.

## References

- Udacity course: Writing Test Suites
- Jasmine.js documentation
- Discussion board clarifications of required tests
